package core;

public class Statement_ {
	
	private String statement_;

	public Statement_(String Statement_) {

		this.statement_ = Statement_;
	}
	
	public String statement_get() {
		return statement_;
	}
	
	public void statement_set(String Statement_) {
		this.statement_ = Statement_;
		
	}
}
