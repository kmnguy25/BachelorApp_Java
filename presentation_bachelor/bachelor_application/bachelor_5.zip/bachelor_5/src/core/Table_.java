package core;

public class Table_ {
	
	private String table_;

	public Table_(String Table_) {

		this.table_ = Table_;
	}
	
	public String table_get() {
		return table_;
	}
	
	public void table_set(String Table_) {
		this.table_ = Table_;
		
	}

}
